# ORM (Object-Relational Mapping) en Python

Investigación de 3.º de Bachillerato en Informática (29 de septiembre de 2026) sobre cómo los datos de una base de datos pueden pasar a Python y trabajarse como objetos, que es lo que hace un ORM.

**Integrantes:** _(agrega aquí los nombres)_

El documento completo está en [`docs/Investigacion_ORM_Python.docx`](docs/Investigacion_ORM_Python.docx). Este repositorio tiene el código de cada ejemplo y sus capturas.

## Contenido

1. [Representaciones de un registro en Python](#1-representaciones-de-un-registro-en-python)
2. [¿Qué es un ORM?](#2-qué-es-un-orm)
3. [Trabajar con objetos en lugar de filas](#3-trabajar-con-objetos-en-lugar-de-filas)
4. [Modelos](#4-modelos)
5. [Objetos y CRUD](#5-objetos-y-crud)
6. [`**kwargs`](#6-kwargs)
7. [`setattr()`](#7-setattr)
8. [Tabla de conceptos](#8-tabla-de-conceptos)
9. [Respuestas a las preguntas de análisis](#9-respuestas-a-las-preguntas-de-análisis)
10. [Conclusión](#10-conclusión)

## Cómo ejecutar los ejemplos

Hace falta Python 3. Los ejemplos usan `sqlite3`, que ya viene con Python; solo el ejemplo de SQLAlchemy necesita instalar la librería.

```bash
git clone <URL-DEL-REPOSITORIO>
cd orm-python-investigacion

python ejemplos/01_tupla.py

# Solo para el ejemplo 09 (SQLAlchemy)
pip install -r requirements.txt
python ejemplos/09_sqlalchemy.py
```

Con MySQL el código es casi igual: cambia la conexión (`mysql.connector.connect(host, user, password, database)`) y el símbolo de los parámetros, que pasa de `?` a `%s`.

El registro de ejemplo que se usa en casi todo el trabajo:

| id | nombre | apellido | correo |
| --- | --- | --- | --- |
| 1 | Ana | Gómez | ana@gmail.com |

---

## 1. Representaciones de un registro en Python

| Representación | Estructura | Acceso | Ventaja | Limitación | Código |
| --- | --- | --- | --- | --- | --- |
| Tupla | `tuple` | Índice | Liviana y no se puede cambiar por error | Sin nombres; no se modifica | [`01_tupla.py`](ejemplos/01_tupla.py) |
| Lista | `list` | Índice | Se puede modificar | Sin nombres | [`02_lista.py`](ejemplos/02_lista.py) |
| Diccionario | `dict` | Clave | Fácil de leer; sirve con JSON y kwargs | No valida campos ni tiene métodos | [`03_diccionario.py`](ejemplos/03_diccionario.py) |
| namedtuple | `namedtuple` | Nombre o índice | Liviana y legible | No se modifica | [`04_namedtuple.py`](ejemplos/04_namedtuple.py) |
| Clase / objeto | `class` | Atributos y métodos | Datos y acciones juntos | Más código | [`05_clase.py`](ejemplos/05_clase.py) |
| dataclass | `@dataclass` | Atributos | Código más corto | No valida tipos | [`06_dataclass.py`](ejemplos/06_dataclass.py) |

**Figura 1.** Tupla  
![Figura 1](capturas/figura_01.png)

**Figura 2.** Lista  
![Figura 2](capturas/figura_02.png)

**Figura 3.** Diccionario  
![Figura 3](capturas/figura_03.png)

**Figura 4.** namedtuple  
![Figura 4](capturas/figura_04.png)

**Figura 5.** Clase y objeto  
![Figura 5](capturas/figura_05.png)

**Figura 6.** dataclass  
![Figura 6](capturas/figura_06.png)

### Cuando hay muchos registros

Los registros se guardan en una lista y cada elemento es un registro ([`07_lista_de_diccionarios.py`](ejemplos/07_lista_de_diccionarios.py)).

**Figura 7.** Lista de diccionarios: recorrer, buscar y sacar una columna  
![Figura 7](capturas/figura_07.png)

**Pregunta de análisis:** si una base de datos contiene muchos registros, ¿qué características debería tener una representación en Python para facilitar su manejo?

- Los campos deben tener nombre, para no depender de la posición.
- Todos los registros deben tener la misma estructura.
- Debe ser una colección que se pueda recorrer, como una lista.
- Debe tener un identificador único (`id`).
- Debe poder modificarse.
- Debería poder tener métodos y ser fácil de convertir desde y hacia la base de datos.

Por eso lo más adecuado es una lista de objetos, que es justo lo que produce un ORM.

## 2. ¿Qué es un ORM?

ORM significa *Object-Relational Mapping* (mapeo objeto-relacional): conecta las tablas de una base de datos con las clases de un lenguaje de programación. La base de datos trabaja con tablas, filas y SQL, y Python con clases y objetos; el ORM hace la conversión entre las dos partes.

| Base de datos | Python |
| --- | --- |
| Tabla `cliente` | Clase `Cliente` |
| Fila o registro | Objeto de la clase `Cliente` |
| Columna o campo (`nombre`) | Atributo (`cliente.nombre`) |
| Clave primaria (`id`) | Atributo que identifica al objeto |
| Operaciones SQL (INSERT, SELECT, UPDATE, DELETE) | Métodos del ORM (guardar, buscar, actualizar, eliminar) |

**Ventajas:** menos SQL y menos código repetido, código más legible, se puede cambiar de motor de base de datos casi sin cambiar el código, las consultas con parámetros ayudan a evitar la inyección SQL y se pueden validar los datos antes de guardarlos.
**Desventaja:** hay que aprender a usarlo y en consultas muy complicadas a veces es mejor escribir el SQL directamente.

### Ejemplo práctico: ORM hecho a mano

[`08_orm_a_mano_sqlite.py`](ejemplos/08_orm_a_mano_sqlite.py)

**Figura 8.** Una fila de la base de datos convertida en un objeto `Cliente`  
![Figura 8](capturas/figura_08.png)

### Ejemplo con SQLAlchemy

[`09_sqlalchemy.py`](ejemplos/09_sqlalchemy.py): el ORM genera el `CREATE TABLE`, el `INSERT` y el `SELECT` por debajo. Salida esperada: `Ana Gómez ana@gmail.com`.

## 3. Trabajar con objetos en lugar de filas

Cada registro se representa como un objeto. Así, en vez de recordar que el precio está en la posición 2 de la fila, se escribe `producto.precio`.

- Una **clase** equivale a una **tabla**.
- Un **objeto** equivale a un **registro**.
- Los **atributos** representan los campos o columnas.

Ejemplo con la entidad Producto: [`10_producto.py`](ejemplos/10_producto.py)

| id | nombre | precio | stock |
| --- | --- | --- | --- |
| 1 | Arroz 1 kg | 1.25 | 40 |
| 2 | Aceite 1 L | 3.10 | 0 |

**Figura 9.** Clase `Producto` con dos objetos y sus métodos  
![Figura 9](capturas/figura_09.png)

## 4. Modelos

Un modelo es una clase que describe cómo es una tabla: su nombre, sus campos, el tipo de cada campo y restricciones como la clave primaria. El ORM lo usa para crear el SQL y convertir las filas en objetos, y la información se define una sola vez. Código: [`11_modelo_cliente.py`](ejemplos/11_modelo_cliente.py)

| En la tabla | En el modelo (clase `Cliente`) |
| --- | --- |
| Nombre de la tabla `cliente` | Nombre de la clase `Cliente` (y el dato `tabla = "cliente"`) |
| Columnas `id`, `nombre`, `apellido`, `correo` | Atributos `self.id`, `self.nombre`, ... y la lista `campos` |
| Clave primaria `id` | Atributo `id` que identifica al objeto |
| Tipos y restricciones (INT, VARCHAR, PRIMARY KEY) | Tipos declarados en el modelo (en SQLAlchemy: `Integer`, `String`, `primary_key=True`) |
| Una fila de la tabla | Un objeto creado con `Cliente(...)` |

**Figura 10.** Modelo `Cliente` que construye el INSERT a partir de sus campos  
![Figura 10](capturas/figura_10.png)

## 5. Objetos y CRUD

| Operación CRUD | SQL | Acción del objeto | Ejemplo |
| --- | --- | --- | --- |
| Create (crear) | INSERT | Guardar un objeto nuevo como registro | `cliente.guardar()` |
| Read (leer) | SELECT | Obtener un registro y convertirlo en objeto | `Cliente.buscar(1)` |
| Update (actualizar) | UPDATE | Guardar los cambios de los atributos | `cliente.actualizar()` |
| Delete (eliminar) | DELETE | Borrar el registro que representa el objeto | `cliente.eliminar()` |

Código: [`12_crud.py`](ejemplos/12_crud.py)

**Figura 11.** Operaciones CRUD hechas desde los métodos del objeto  
![Figura 11](capturas/figura_11.png)

## 6. `**kwargs`

`kwargs` viene de *keyword arguments* (argumentos con nombre). Los dos asteriscos se usan de dos formas: en la definición (`def f(**kwargs)`) juntan los argumentos con nombre en un diccionario, y en la llamada (`f(**diccionario)`) abren un diccionario y lo envían como argumentos con nombre. Internamente `kwargs` es un `dict`.

| Ejemplo | Código | Captura |
| --- | --- | --- |
| 1. Recibir diferentes cantidades de argumentos | [`13_kwargs_ejemplo1.py`](ejemplos/13_kwargs_ejemplo1.py) | ![Figura 12](capturas/figura_12.png) |
| 2. Recorrer los datos recibidos | [`14_kwargs_ejemplo2.py`](ejemplos/14_kwargs_ejemplo2.py) | ![Figura 13](capturas/figura_13.png) |
| 3. Acceder a los valores por su nombre | [`15_kwargs_ejemplo3.py`](ejemplos/15_kwargs_ejemplo3.py) | ![Figura 14](capturas/figura_14.png) |
| 4. Crear un objeto que representa un registro | [`16_kwargs_ejemplo4.py`](ejemplos/16_kwargs_ejemplo4.py) | ![Figura 15](capturas/figura_15.png) |
| 5. Diferencia entre `*args` y `**kwargs` | [`17_args_vs_kwargs.py`](ejemplos/17_args_vs_kwargs.py) | ![Figura 16](capturas/figura_16.png) |

**Pregunta de análisis:** ¿qué ventaja podría tener utilizar `**kwargs` para crear objetos que representan registros de una base de datos?

Un registro se puede pasar a un diccionario y con `**kwargs` ese diccionario se envía directo al constructor con `Cliente(**fila)`. Además, el mismo constructor sirve para cualquier cantidad de campos, los datos se identifican por nombre y no por posición, y los campos que falten pueden tener un valor por defecto con `kwargs.get(...)`.

## 7. `setattr()`

`setattr(objeto, "nombre_del_atributo", valor)` le da un valor a un atributo usando su nombre como texto (si no existe, lo crea). Es lo mismo que `objeto.nombre_del_atributo = valor`, pero el nombre puede venir de una variable, por eso se dice que trabaja de forma dinámica. La función contraria es `getattr()`.

| Ejemplo | Código | Captura |
| --- | --- | --- |
| Básico con `setattr()` y `getattr()` | [`18_setattr_basico.py`](ejemplos/18_setattr_basico.py) | ![Figura 17](capturas/figura_17.png) |
| Con una variable como nombre del atributo | [`19_setattr_variable.py`](ejemplos/19_setattr_variable.py) | ![Figura 18](capturas/figura_18.png) |
| Simulación de un ORM con `**kwargs` y `setattr()` | [`20_cliente_orm_kwargs_setattr.py`](ejemplos/20_cliente_orm_kwargs_setattr.py) | ![Figura 19](capturas/figura_19.png) |

**Pregunta de análisis:** ¿por qué podría ser útil `setattr()` cuando se desea convertir información almacenada en un diccionario en atributos de un objeto?

Porque los datos de la base de datos llegan como un diccionario donde cada clave es el nombre de una columna. Con `setattr()` se recorre el diccionario y se crea un atributo por cada clave, sin escribir una línea por campo y sin saber antes cuántos ni cuáles son. Así la misma clase sirve para cualquier tabla. Los ORM usan esta técnica para convertir las filas en objetos.

## 8. Tabla de conceptos

| Concepto | Definición | Función en un ORM | Ejemplo |
| --- | --- | --- | --- |
| Tabla | Estructura de filas y columnas de una base de datos | Se representa con una clase | `cliente` |
| Registro (fila) | Conjunto de datos de una tabla | Se representa con un objeto | `(1, "Ana", "Gómez", ...)` |
| Campo (columna) | Un dato de la tabla | Se representa con un atributo | `nombre` |
| Clave primaria | Campo que identifica cada registro | Permite buscar, actualizar y eliminar un objeto | `id` |
| Clase | Molde que define atributos y métodos | Modelo de la tabla | `class Cliente` |
| Objeto | Instancia de una clase | Representa un registro | `c = Cliente(1, "Ana", ...)` |
| Atributo | Variable que pertenece a un objeto | Guarda el valor de un campo | `c.correo` |
| Método | Función dentro de una clase | Hace operaciones sobre el registro | `c.guardar()` |
| Modelo | Clase que describe una tabla | Permite crear el SQL y los objetos | `Cliente(Base)` |
| Mapeo | Correspondencia entre la base de datos y Python | Es la idea principal del ORM | Tabla = clase, fila = objeto |
| CRUD | Crear, leer, actualizar y eliminar | Operaciones que el ORM pasa a SQL | INSERT, SELECT, UPDATE, DELETE |
| `**kwargs` | Recibe argumentos con nombre en un diccionario | Crea objetos con datos que traen el nombre del campo | `Cliente(**fila)` |
| `setattr()` | Asigna un atributo usando su nombre en texto | Convierte las claves de un diccionario en atributos | `setattr(obj, "correo", v)` |
| Conexión | Comunicación con la base de datos | Envía el SQL y recibe los resultados | `sqlite3.connect(...)` |

## 9. Respuestas a las preguntas de análisis

- **Muchos registros (sección 1):** campos con nombre, misma estructura, colección que se pueda recorrer, identificador único, poder modificarse y poder tener métodos. Lo mejor es una lista de objetos.
- **Ventaja de `**kwargs` (sección 6):** crea el objeto directo desde un diccionario con `Cliente(**fila)`, sirve para cualquier cantidad de campos, los identifica por nombre y permite valores por defecto.
- **Utilidad de `setattr()` (sección 7):** asigna un atributo por cada clave del diccionario sin conocer los campos de antemano, así que una misma clase sirve para cualquier tabla.

## 10. Conclusión

Python y los ORM ayudan a conectar los objetos de un programa con los datos guardados en una base de datos. Con el mapeo, cada tabla se vuelve una clase, cada registro un objeto y cada campo un atributo, así que en vez de trabajar con posiciones de una fila o con texto SQL se puede escribir `cliente.nombre`. Herramientas de Python como `**kwargs` y `setattr()` permiten crear esos objetos a partir de un diccionario sin importar cuántos campos tenga la tabla. Además, los métodos de los objetos equivalen a las operaciones CRUD y el ORM se encarga de convertirlas a SQL. De esta forma el código queda más ordenado y fácil de mantener, y la lógica del programa queda separada de los detalles de la base de datos.

## Referencias

- Python Software Foundation. (s. f.). Built-in Functions: setattr(), getattr(). Python 3 Documentation. https://docs.python.org/3/library/functions.html
- Python Software Foundation. (s. f.). More Control Flow Tools: keyword arguments. Python 3 Documentation. https://docs.python.org/3/tutorial/controlflow.html
- Python Software Foundation. (s. f.). sqlite3: DB-API 2.0 interface for SQLite databases. https://docs.python.org/3/library/sqlite3.html
- SQLAlchemy. (s. f.). SQLAlchemy ORM Quick Start. https://docs.sqlalchemy.org/en/20/orm/quickstart.html
