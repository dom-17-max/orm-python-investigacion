from collections import namedtuple

Cliente = namedtuple("Cliente", ["id", "nombre", "apellido", "correo"])
c = Cliente(1, "Ana", "Gómez", "ana@gmail.com")

print(c)
print(c.nombre)      # acceso por nombre
print(c[3])          # también funciona el acceso por índice
