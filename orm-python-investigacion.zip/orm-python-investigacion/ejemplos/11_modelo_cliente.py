class Cliente:
    # --- Definición del modelo (estructura de la tabla) ---
    tabla = "cliente"
    campos = ["id", "nombre", "apellido", "correo"]

    # --- Cada objeto es un registro ---
    def __init__(self, id=None, nombre=None, apellido=None, correo=None):
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.correo = correo

    def a_diccionario(self):
        return {campo: getattr(self, campo) for campo in self.campos}

    @classmethod
    def sql_insert(cls):
        columnas = ", ".join(cls.campos)
        marcas = ", ".join("?" for _ in cls.campos)
        return f"INSERT INTO {cls.tabla} ({columnas}) VALUES ({marcas})"


c = Cliente(1, "Ana", "Gómez", "ana@gmail.com")
print(c.a_diccionario())
print(Cliente.sql_insert())     # el modelo permite construir el SQL automáticamente
