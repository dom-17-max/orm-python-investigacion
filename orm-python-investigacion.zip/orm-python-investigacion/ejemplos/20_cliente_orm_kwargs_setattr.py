class ClienteORM:
    def __init__(self, **kwargs):
        # Recorre el diccionario y asigna atributos dinámicamente
        for campo, valor in kwargs.items():
            setattr(self, campo, valor)


# Datos simulados que vienen de una base de datos
datos_db = {
    "id": 1,
    "nombre_cliente": "Ana Gómez",
    "telefono": "555-9876",
}

# Creamos el objeto dinámicamente usando **kwargs y setattr()
cliente = ClienteORM(**datos_db)

print("Atributo ID obtenido con setattr:", cliente.id)
print("Atributo Nombre obtenido con setattr:", cliente.nombre_cliente)
print("Atributo Teléfono obtenido con setattr:", cliente.telefono)
