import sqlite3


class Cliente:
    """Cada objeto Cliente representa una fila de la tabla cliente."""
    def __init__(self, id, nombre, apellido, correo):
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.correo = correo

    def __repr__(self):
        return f"Cliente(id={self.id}, nombre=\x27{self.nombre}\x27, apellido=\x27{self.apellido}\x27, correo=\x27{self.correo}\x27)"


# Base de datos de ejemplo (en memoria)
conexion = sqlite3.connect(":memory:")
cursor = conexion.cursor()
cursor.execute("CREATE TABLE cliente (id INTEGER PRIMARY KEY, nombre TEXT, apellido TEXT, correo TEXT)")
cursor.execute("INSERT INTO cliente VALUES (1, \x27Ana\x27, \x27Gómez\x27, \x27ana@gmail.com\x27)")

# Lo que devuelve la base de datos: una fila (tupla)
fila = cursor.execute("SELECT * FROM cliente WHERE id = 1").fetchone()
print("Fila cruda :", fila)

# Mapeo: la fila se convierte en un objeto
cliente = Cliente(*fila)
print("Objeto     :", cliente)
print("Nombre     :", cliente.nombre)
print("Correo     :", cliente.correo)
