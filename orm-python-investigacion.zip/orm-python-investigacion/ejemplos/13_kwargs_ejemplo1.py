def mostrar_datos(**kwargs):
    print("Tipo recibido       :", type(kwargs))
    print("Cantidad de datos   :", len(kwargs))
    print("Contenido           :", kwargs)


mostrar_datos(nombre="Ana")
mostrar_datos(nombre="Ana", apellido="Gómez", correo="ana@gmail.com")
mostrar_datos()          # también se puede llamar sin argumentos
