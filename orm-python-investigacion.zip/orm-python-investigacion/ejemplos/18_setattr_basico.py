class Persona:
    pass


p = Persona()
setattr(p, "nombre", "Ana")      # equivale a: p.nombre = "Ana"
print(p.nombre)
print(getattr(p, "nombre"))      # getattr es la función complementaria
