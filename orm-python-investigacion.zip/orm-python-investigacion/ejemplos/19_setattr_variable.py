class Persona:
    pass


p = Persona()

campo = "correo"                 # el nombre del atributo está en una variable
valor = "ana@gmail.com"
setattr(p, campo, valor)
print(p.correo)

for campo, valor in {"edad": 20, "activo": True}.items():
    setattr(p, campo, valor)
print(p.edad, p.activo)
print(p.__dict__)
