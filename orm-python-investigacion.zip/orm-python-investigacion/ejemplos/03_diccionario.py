# Registro representado como diccionario
registro = {"id": 1, "nombre": "Ana", "apellido": "Gómez", "correo": "ana@gmail.com"}

print(registro["nombre"])                # acceso por clave
print(registro.get("telefono", "sin dato"))   # acceso seguro con valor por defecto
for campo, valor in registro.items():    # recorrido de todos los campos
    print(f"{campo}: {valor}")
