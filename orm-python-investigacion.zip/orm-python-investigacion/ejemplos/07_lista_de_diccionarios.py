# Varios registros: una lista donde cada elemento es un diccionario
clientes = [
    {"id": 1, "nombre": "Ana",   "apellido": "Gómez", "correo": "ana@gmail.com"},
    {"id": 2, "nombre": "Luis",  "apellido": "Pérez", "correo": "luis@gmail.com"},
    {"id": 3, "nombre": "Marta", "apellido": "Ruiz",  "correo": "marta@gmail.com"},
]

print("Total de registros:", len(clientes))
for c in clientes:                       # recorrer
    if c["id"] == 2:                     # buscar por identificador
        print("Encontrado:", c["nombre"], c["apellido"])
print([c["correo"] for c in clientes])   # extraer una columna completa
