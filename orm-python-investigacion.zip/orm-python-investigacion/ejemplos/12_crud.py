import sqlite3

conexion = sqlite3.connect(":memory:")
conexion.execute("CREATE TABLE cliente (id INTEGER PRIMARY KEY, nombre TEXT, apellido TEXT, correo TEXT)")


class Cliente:
    def __init__(self, id, nombre, apellido, correo):
        self.id, self.nombre, self.apellido, self.correo = id, nombre, apellido, correo

    def guardar(self):                                   # CREATE  -> INSERT
        conexion.execute("INSERT INTO cliente VALUES (?, ?, ?, ?)",
                         (self.id, self.nombre, self.apellido, self.correo))
        conexion.commit()

    @classmethod
    def buscar(cls, id):                                 # READ    -> SELECT
        fila = conexion.execute("SELECT * FROM cliente WHERE id = ?", (id,)).fetchone()
        return cls(*fila) if fila else None

    def actualizar(self):                                # UPDATE  -> UPDATE
        conexion.execute("UPDATE cliente SET nombre=?, apellido=?, correo=? WHERE id=?",
                         (self.nombre, self.apellido, self.correo, self.id))
        conexion.commit()

    def eliminar(self):                                  # DELETE  -> DELETE
        conexion.execute("DELETE FROM cliente WHERE id = ?", (self.id,))
        conexion.commit()


c = Cliente(1, "Ana", "Gómez", "ana@gmail.com")
c.guardar()
print("CREATE + READ:", Cliente.buscar(1).correo)

c.correo = "ana.gomez@gmail.com"
c.actualizar()
print("UPDATE       :", Cliente.buscar(1).correo)

c.eliminar()
print("DELETE       :", Cliente.buscar(1))
