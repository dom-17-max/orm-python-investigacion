def comparar(x, *args, **kwargs):
    print("x      :", x)
    print("args   :", args)       # tupla con los argumentos posicionales sobrantes
    print("kwargs :", kwargs)     # diccionario con los argumentos con nombre sobrantes


comparar(1, 2, 3, nombre="Ana", activo=True)
