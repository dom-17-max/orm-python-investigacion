# Registro representado como tupla
registro = (1, "Ana", "Gómez", "ana@gmail.com")

print(registro)                 # la tupla completa
print(registro[1])              # acceso por índice
id_cliente, nombre, apellido, correo = registro   # desempaquetado
print(nombre, apellido, correo)
