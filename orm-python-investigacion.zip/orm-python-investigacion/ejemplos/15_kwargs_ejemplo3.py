def resumen_cliente(id, **kwargs):
    nombre = kwargs.get("nombre", "Sin nombre")     # acceso por nombre con valor por defecto
    correo = kwargs.get("correo", "Sin correo")
    return f"[{id}] {nombre} <{correo}>"


print(resumen_cliente(1, nombre="Ana", correo="ana@gmail.com"))
print(resumen_cliente(2, nombre="Luis"))            # falta el correo: no genera error
