# Requiere: pip install sqlalchemy
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import declarative_base, Session

Base = declarative_base()


class Cliente(Base):                       # la clase es el modelo de la tabla
    __tablename__ = "cliente"
    id = Column(Integer, primary_key=True)
    nombre = Column(String(50))
    apellido = Column(String(50))
    correo = Column(String(80))


engine = create_engine("sqlite:///:memory:")
Base.metadata.create_all(engine)           # el ORM genera el CREATE TABLE

with Session(engine) as sesion:
    sesion.add(Cliente(id=1, nombre="Ana", apellido="Gómez", correo="ana@gmail.com"))
    sesion.commit()                        # el ORM genera el INSERT
    c = sesion.get(Cliente, 1)             # el ORM genera el SELECT
    print(c.nombre, c.apellido, c.correo)
