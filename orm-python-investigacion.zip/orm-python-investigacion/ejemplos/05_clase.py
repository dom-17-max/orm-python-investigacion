class Cliente:
    def __init__(self, id, nombre, apellido, correo):
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.correo = correo

    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"


c = Cliente(1, "Ana", "Gómez", "ana@gmail.com")
print(c.nombre)                 # acceso a un atributo
print(c.nombre_completo())      # ejecución de un método
c.correo = "ana.gomez@gmail.com"   # modificación del atributo
print(c.correo)
