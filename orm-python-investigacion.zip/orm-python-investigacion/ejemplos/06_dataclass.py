from dataclasses import dataclass


@dataclass
class Cliente:
    id: int
    nombre: str
    apellido: str
    correo: str


c = Cliente(1, "Ana", "Gómez", "ana@gmail.com")
print(c)            # __repr__ generado automáticamente
print(c.correo)
