class Producto:
    """Clase = tabla producto | Objeto = un registro | Atributo = un campo"""
    def __init__(self, id, nombre, precio, stock):
        self.id = id
        self.nombre = nombre
        self.precio = precio
        self.stock = stock

    def hay_stock(self):
        return self.stock > 0

    def vender(self, cantidad):
        if cantidad <= self.stock:
            self.stock -= cantidad
            return True
        return False


p1 = Producto(1, "Arroz 1 kg", 1.25, 40)     # registro 1
p2 = Producto(2, "Aceite 1 L", 3.10, 0)      # registro 2

print(p1.nombre, "- precio:", p1.precio)     # en lugar de fila[1] y fila[2]
print("p1 con stock:", p1.hay_stock())
print("p2 con stock:", p2.hay_stock())
p1.vender(5)
print("Stock de p1 después de vender 5:", p1.stock)
