class Cliente:
    def __init__(self, **kwargs):
        self.id = kwargs.get("id")
        self.nombre = kwargs.get("nombre")
        self.apellido = kwargs.get("apellido")
        self.correo = kwargs.get("correo")


# Datos que podrían venir de una consulta a la base de datos
fila_db = {"id": 1, "nombre": "Ana", "apellido": "Gómez", "correo": "ana@gmail.com"}

cliente = Cliente(**fila_db)      # ** desempaqueta el diccionario en argumentos con nombre
print(cliente.id, cliente.nombre, cliente.apellido, cliente.correo)
