# Registro representado como lista
registro = [1, "Ana", "Gómez", "ana@gmail.com"]

print(registro[3])                       # acceso por índice
registro[3] = "ana.gomez@gmail.com"      # las listas sí se pueden modificar
print(registro)
print(registro[1:3])                     # acceso por rebanada (slicing)
