def imprimir_registro(**kwargs):
    for campo, valor in kwargs.items():      # kwargs es un diccionario
        print(f"{campo} = {valor}")


imprimir_registro(id=1, nombre="Ana", apellido="Gómez", correo="ana@gmail.com")
